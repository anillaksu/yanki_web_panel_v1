from flask import Flask, render_template, request, jsonify
import os, uuid, subprocess, json

app = Flask(__name__, template_folder='templates', static_folder='static')

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/generate/scene", methods=["POST"])
def gen_scene():
    data = request.get_json(force=True)
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "Boş metin olmaz!"}), 400
    sid = f"scene_{uuid.uuid4().hex[:8]}"
    out_dir = os.path.join("output", sid)
    os.makedirs(out_dir, exist_ok=True)

    # --- Dummy üretim (modülleri gerçek kodla değiştirebilirsin) ---
    open(os.path.join(out_dir, "image.png"), "wb").write(b"")      # placeholder
    open(os.path.join(out_dir, "audio.wav"), "wb").write(b"")      # placeholder
    open(os.path.join(out_dir, "subtitles.srt"), "w").write("1\n") # placeholder
    open(os.path.join(out_dir, "final_video.mp4"), "wb").write(b"")

    return jsonify({
        "scene_id": sid,
        "video_url": f"/download/{sid}"
    })

@app.route("/download/<sid>")
def dl(sid):
    path = os.path.join("output", sid, "final_video.mp4")
    return app.send_static_file(path) if os.path.exists(path) else ("Dosya yok", 404)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
